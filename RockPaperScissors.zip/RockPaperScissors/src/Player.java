
public abstract class Player {
RoshamboValue Roshambo; //0 is rock, 1 is paper, 2 is scissors
String Name;
public abstract void getRoshambo();
public abstract void getName();
}
