
public enum RoshamboValue {
rock, paper, scissors
}
