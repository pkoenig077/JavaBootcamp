
public class RockPlayer extends Player {

	@Override
	public void getRoshambo() {
		Roshambo = RoshamboValue.rock;
		System.out.println("Rock");
		Name = "Rock Player";
	}

	@Override
	public void getName() {
		// TODO Auto-generated method stub
		
	}

}
